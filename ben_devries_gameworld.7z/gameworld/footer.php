<!--footer.php for the php include-->
<div id="home-footer">
    <footer>&copy; 2018 Ben de Vries</footer>
</div>