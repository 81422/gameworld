<!--navigation.php for the php include-->
<div id="logo"><a href="index.php">GAMEWORLD</div>
    <header id="header">
		<nav id="main-nav">
			<ul>
				<li><a href="index.php">Home</a></li>
				<div class="dropdown">
    			<a class="dropbtn" href="gamespage.php?gameCat=0">Games</a>
    			<div class="dropdown-content">
      		<a href="gamespage.php?gameCat=1">Playstation 4</a>
      		<a href="gamespage.php?gameCat=2">XBOX ONE</a>
					<a href="gamespage.php?gameCat=3">Nintendo Switch</a>
    			</div>
  			</div> 
				<li><a href="contactpage.php">Contact</a></li>
				<li><a href="aboutpage.php">About Us</a></li>
				<li><a href="checkoutpage.php">Checkout</a></li>
			</ul>
		</nav>
    </header>